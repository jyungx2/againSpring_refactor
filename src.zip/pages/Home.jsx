import { createBrowserRouter } from "react-router-dom";
import homeRoutes from "@routes/homeRoutes";
import Home from "@components/layouts/index";
import Login from "@pages/user/Login";

const routes = createBrowserRouter([
  {
    path: "/",
    element: <Home />,
    children: [...homeRoutes],
  },
  { path: "login", element: <Login /> },
]);

export default routes;
